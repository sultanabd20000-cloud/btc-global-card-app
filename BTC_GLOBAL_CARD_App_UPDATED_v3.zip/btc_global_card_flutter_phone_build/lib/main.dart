import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String appUrl = 'https://btccoin.site/';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BtcGlobalCardApp());
}

class BtcGlobalCardApp extends StatelessWidget {
  const BtcGlobalCardApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BTC GLOBAL CARD',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF07111F),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFF5B400),
          brightness: Brightness.dark,
        ),
      ),
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  late final WebViewController _controller;
  int _progress = 0;
  bool _pageLoading = true;
  bool _offline = false;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF07111F))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (value) {
            if (!mounted) return;
            setState(() => _progress = value);
          },
          onPageStarted: (_) {
            if (!mounted) return;
            setState(() {
              _pageLoading = true;
              _offline = false;
            });
          },
          onPageFinished: (_) {
            if (!mounted) return;
            setState(() {
              _pageLoading = false;
              _offline = false;
              _progress = 100;
            });
          },
          onWebResourceError: (error) {
            // A WebView can report errors for images, fonts, ads, analytics,
            // etc. Do NOT show the whole app as offline for those errors.
            // Only a main-frame error means the actual page failed to load.
            if (error.isForMainFrame != true) return;
            if (!mounted) return;
            setState(() {
              _pageLoading = false;
              _offline = true;
            });
          },
          onNavigationRequest: (request) {
            final uri = Uri.tryParse(request.url);
            if (uri == null) return NavigationDecision.prevent;

            if (uri.scheme == 'http' || uri.scheme == 'https') {
              return NavigationDecision.navigate;
            }

            launchUrl(uri, mode: LaunchMode.externalApplication);
            return NavigationDecision.prevent;
          },
        ),
      )
      ..loadRequest(Uri.parse(appUrl));
  }

  Future<void> _refresh() async {
    if (!mounted) return;
    setState(() {
      _offline = false;
      _pageLoading = true;
      _progress = 0;
    });

    try {
      await _controller.reload();
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _pageLoading = false;
        _offline = true;
      });
    }
  }

  Future<bool> _handleBack() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: _handleBack,
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              WebViewWidget(controller: _controller),
              if (_pageLoading && !_offline)
                const Center(
                  child: CircularProgressIndicator(),
                ),
              if (_offline)
                Container(
                  color: const Color(0xFF07111F),
                  alignment: Alignment.center,
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.cloud_off_rounded, size: 56),
                        const SizedBox(height: 16),
                        const Text(
                          'Unable to load BTC GLOBAL CARD',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Please check your internet connection and try again.',
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 20),
                        FilledButton.icon(
                          onPressed: _refresh,
                          icon: const Icon(Icons.refresh),
                          label: const Text('Try again'),
                        ),
                      ],
                    ),
                  ),
                ),
              if (_progress < 100 && !_offline)
                Align(
                  alignment: Alignment.topCenter,
                  child: LinearProgressIndicator(
                    value: _progress / 100,
                    minHeight: 2,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
