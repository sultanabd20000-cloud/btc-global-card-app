# BTC GLOBAL CARD — Updated Phone Build

This Flutter app wraps the existing BTC COIN website at `https://btccoin.site/`.

## Network fix included
- Android `INTERNET` permission is explicitly included.
- The app no longer treats errors from images, fonts, ads, analytics, or other WebView sub-resources as a full internet failure.
- The offline screen is shown only when the main web page fails to load.
- Retry reloads the page directly.
- HTTPS is used for the website URL.

## Build
The GitHub Actions workflow can create the Android project, install dependencies, and build the release APK.

## Important
The website/backend, payment processing, crypto verification, Telegram credentials, and database secrets remain server-side. They are not placed in the APK.
