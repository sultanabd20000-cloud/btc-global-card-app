# BTC GLOBAL CARD — Phone Build

This is a Flutter project prepared to build the BTC COIN web platform as an Android app. The app uses the existing HTTPS website as its authenticated web backend, so current website login/session/pages can remain on the server.

## Important

- Current app URL: `https://btccoin.site/`
- If your production domain changes, edit `appUrl` in `lib/main.dart`.
- No database password, payment secret, Telegram bot token, or crypto private key is stored in the Flutter app.
- This project includes a GitHub Actions workflow so an APK can be built from a phone without installing Android Studio on the phone.

## Build from a phone with GitHub

1. Open GitHub in your phone browser and create a new repository, e.g. `btc-global-card-app`.
2. Upload all files from this project into that repository, including `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK**.
5. Tap **Run workflow**.
6. Wait for the workflow to finish.
7. Open the completed workflow run and download the artifact named **btc-global-card-apk**.
8. Extract the downloaded artifact and install the APK on your Android phone.

The workflow creates the Android project with the current Flutter toolchain, installs dependencies, and builds a release APK.

## Local Flutter build

If later you install Flutter on a computer:

```bash
flutter pub get
flutter build apk --release
```

## Security

The app is only a client. Payment/crypto verification and balance updates must remain server-side in the existing PHP API.
